if flo==0
    nStr=0
    nStr_active=0
    nFl=0
    nd_fl=[]
    nd_Str_active=[]
end
